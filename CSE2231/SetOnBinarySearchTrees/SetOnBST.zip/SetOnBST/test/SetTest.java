import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Gabe Azzarita and Ty Fredrick
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    // Testing empty (default) constructor
    @Test
    public final void testForDefaultConstructor() {
        Set<String> test = this.constructorTest();
        Set<String> ref = this.constructorRef();

        assertEquals(test, ref);
    }

    // Testing constructor when passing in an arg
    @Test
    public final void testForConstructorEasy() {
        Set<String> test = this.createFromArgsTest("1");
        Set<String> ref = this.createFromArgsRef("1");

        assertEquals(test, ref);
    }

    // Testing constructor when passing in multiple args
    @Test
    public final void testForConstructorHard() {
        Set<String> test = this.createFromArgsTest("January", "February",
                "March", "April", "May", "June", "July", "August", "September",
                "October", "November", "December");
        Set<String> ref = this.createFromArgsRef("January", "February", "March",
                "April", "May", "June", "July", "August", "September",
                "October", "November", "December");

        assertEquals(test, ref);
    }

    // Testing add with one element
    @Test
    public final void testForAddOne() {
        Set<String> test = this.constructorTest();
        Set<String> ref = this.createFromArgsRef("purple");

        test.add("purple");

        assertEquals(test, ref);
    }

    // Testing add with multiple elements easy
    @Test
    public final void testForAddTwo() {
        Set<String> test = this.constructorTest();
        Set<String> ref = this.createFromArgsRef("Patriots", "Jets");

        test.add("Patriots");
        test.add("Jets");

        assertEquals(test, ref);
    }

    // Testing add with many elements
    @Test
    public final void testForAddMultiple() {
        Set<String> test = this.constructorTest();
        Set<String> ref = this.createFromArgsRef("A", "B", "C", "1", "2", "3");

        test.add("A");
        test.add("B");
        test.add("C");
        test.add("1");
        test.add("2");
        test.add("3");

        assertEquals(test, ref);
    }

    // Testing remove with one element
    @Test
    public final void testForRemoveOne() {
        Set<String> test = this.createFromArgsTest("green");
        Set<String> ref = this.constructorRef();

        String rem = test.remove("green");

        // Make sure remove properly returns string
        assertEquals(rem, "green");
        assertEquals(test, ref);
    }

    // Testing remove with multiple elements easy
    @Test
    public final void testForRemoveMultiple() {
        Set<String> test = this.createFromArgsTest("A", "B", "C", "D");
        Set<String> ref = this.createFromArgsRef("A", "C");

        String rem1 = test.remove("B");
        String rem2 = test.remove("D");

        // Make sure remove properly returns string
        assertEquals(rem1, "B");
        assertEquals(rem2, "D");
        assertEquals(test, ref);
    }

    // Testing remove with multiple elements hard
    @Test
    public final void testForRemoveHard() {
        Set<String> test = this.createFromArgsTest("W", "X", "Y", "Z");
        Set<String> ref = this.constructorRef();

        String rem1 = test.remove("W");
        String rem2 = test.remove("X");
        String rem3 = test.remove("Y");
        String rem4 = test.remove("Z");

        // Make sure remove properly returns string
        assertEquals(rem1, "W");
        assertEquals(rem2, "X");
        assertEquals(rem3, "Y");
        assertEquals(rem4, "Z");
        assertEquals(test, ref);
    }

    // Testing removeAny with one element
    @Test
    public final void testForRemoveAnyOne() {
        Set<String> test = this.createFromArgsTest("Bengals");
        Set<String> ref = this.constructorRef();

        String rem1 = test.removeAny();

        // Make sure remove properly returns string
        assertEquals(rem1, "Bengals");
        assertEquals(test, ref);
    }

    // Testing removeAny with two elements in Set
    @Test
    public final void testForRemoveAnyTwo() {
        Set<String> test = this.createFromArgsTest("Salt", "Pepper", "Cumin");
        Set<String> ref = this.createFromArgsRef("Salt", "Pepper", "Cumin");

        String remTest = test.removeAny();
        String remExp = ref.remove(remTest);

        // Make sure removeAny returns string and check Sets for equality
        assertEquals(remTest, remExp);
        assertEquals(test, ref);
    }

    // Testing multiple removeAny calls in big set
    @Test
    public final void testForRemoveAnyHard() {
        Set<String> test = this.createFromArgsTest("pink", "red", "blue",
                "yellow", "orange", "green", "purple");
        Set<String> ref = this.createFromArgsRef("pink", "red", "blue",
                "yellow", "orange", "green", "purple");

        String remTest1 = test.removeAny();
        String remTest2 = test.removeAny();
        String remExp1 = ref.remove(remTest1);
        String remExp2 = ref.remove(remTest2);

        // Make sure removeAny returns string and check Sets for equality
        assertEquals(remTest1, remExp1);
        assertEquals(remTest2, remExp2);
        assertEquals(test, ref);
    }

    // Testing contains with empty Set
    @Test
    public final void testForContainsFalseNoElement() {
        Set<String> test = this.constructorTest();

        assertEquals(test.contains("hello"), false);
    }

    // Testing contains with one element that is not in set
    @Test
    public final void testForContainsFalseOneElement() {
        Set<String> test = this.createFromArgsTest("red");

        assertEquals(test.contains("orange"), false);
    }

    // Testing contains with multiple element that are not in set
    @Test
    public final void testForContainsFalseMultiple() {
        Set<String> test = this.createFromArgsTest("apple", "banana", "cherry",
                "date", "fig", "grape", "honeydew", "kiwi", "lemon");
        Set<String> ref = this.createFromArgsRef("apple", "banana", "cherry",
                "date", "fig", "grape", "honeydew", "kiwi", "lemon");

        assertEquals(test.contains("mango"), false);
        assertEquals(test.contains("watermelon"), false);
        assertEquals(test.contains("papaya"), false);

        assertEquals(test, ref);
    }

    // Testing contains with one element that is in set
    @Test
    public final void testForContainsTrueOneElement() {
        Set<String> test = this.createFromArgsTest("red");

        assertEquals(test.contains("red"), true);
    }

    // Testing contains with multiple element that are not in set
    @Test
    public final void testForContainsTrueMultiple() {
        Set<String> test = this.createFromArgsTest("apple", "banana", "cherry",
                "date", "fig", "grape", "honeydew", "kiwi", "lemon");
        Set<String> ref = this.createFromArgsRef("apple", "banana", "cherry",
                "date", "fig", "grape", "honeydew", "kiwi", "lemon");

        assertEquals(test.contains("banana"), true);
        assertEquals(test.contains("cherry"), true);
        assertEquals(test.contains("honeydew"), true);

        assertEquals(test, ref);
    }

    // Testing size when set is empty
    @Test
    public final void testForSizeZero() {
        Set<String> test = this.constructorTest();

        assertEquals(test.size(), 0);
    }

    // Testing size when set has one element
    @Test
    public final void testForSizeOne() {
        Set<String> test = this.createFromArgsTest("computer");

        assertEquals(test.size(), 1);
    }

    // Testing size when set has multiple elements
    @Test
    public final void testForSizeMultiple() {
        Set<String> test = this.createFromArgsTest("Joy", "Sadness", "Anger",
                "Fear", "Surprise", "Disgust", "Love", "Excitement", "Anxiety",
                "Guilt", "Envy", "Jealousy");

        final int twelve = 12;

        assertEquals(test.size(), twelve);
    }
}
