import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Put your name here
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    /*
     * Sample test cases.
     */

    // Test for default constructor
    @Test
    public final void testConstructor() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);

        assertEquals(mExpected, m);
    }

    // Test for constructor with one arg
    @Test
    public final void testForOneArg() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1");
        SortingMachine<String> mExp = this.createFromArgsRef(ORDER, true, "1");

        assertEquals(mExp, m);
    }

    // Test for constructor with multiple args
    @Test
    public final void testForMultipleArg() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "apple,", "banana", "cherry", "date", "elderberry");
        SortingMachine<String> mExp = this.createFromArgsRef(ORDER, true,
                "apple,", "banana", "cherry", "date", "elderberry");

        assertEquals(mExp, m);
    }

    // Test for add to empty sorting machine
    @Test
    public final void testAddEmpty() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExp = this.createFromArgsRef(ORDER, true, "r");
        m.add("r");
        assertEquals(mExp, m);
    }

    // Test for multiple add calls
    @Test
    public final void add() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green", "blue", "yellow");
        m.add("blue");
        m.add("yellow");
        m.add("green");

        assertEquals(mExpected, m);
    }

    // Test for changing to extraction mode
    @Test
    public final void testChangeToExtractionModeEmpty() {
        // Default constructor creates sorting machine with insertion mode
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        assertEquals(mExpected, m);
    }

    // Test for changing to extraction mode
    @Test
    public final void testChangeToExtractionModeNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "apple,", "banana", "cherry", "date", "elderberry");
        SortingMachine<String> mExp = this.createFromArgsRef(ORDER, true,
                "apple,", "banana", "cherry", "date", "elderberry");

        m.changeToExtractionMode();
        mExp.changeToExtractionMode();

        assertEquals(mExp.isInInsertionMode(), m.isInInsertionMode());
        assertEquals(mExp, m);
    }

    // Test for removeFirst one item
    @Test
    public final void removeFirstOneItem() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "6");
        SortingMachine<String> mExpected = this.constructorRef(ORDER);

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        String str = m.removeFirst();

        assertEquals(mExpected, m);
        assertEquals(str, "6");
    }

    // Test for removeFirst multiple items
    @Test
    public final void removeFirst() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "4", "3", "7", "6");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "4", "6", "7");

        m.changeToExtractionMode();
        // need to change to extraction mode so assertEquals works
        mExpected.changeToExtractionMode();

        String str1 = m.removeFirst();
        String str2 = m.removeFirst();

        assertEquals(mExpected, m);
        assertEquals(str1, "1");
        assertEquals(str2, "3");
    }

    // Test for IsInsertionModeTrue
    @Test
    public final void testIsInsertionModeTrue() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");

        assertEquals(m.isInInsertionMode(), mExpected.isInInsertionMode());
        assertEquals(m.isInInsertionMode(), true);
        assertEquals(mExpected, m);
    }

    // Test for IsInsertionModeTrue
    @Test
    public final void testIsInsertionModeFalse() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        assertEquals(m.isInInsertionMode(), mExpected.isInInsertionMode());
        assertEquals(m.isInInsertionMode(), false);
        assertEquals(mExpected, m);
    }

    // Test for order
    @Test
    public final void testOrderEmpty() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);

        assertEquals(m.order(), mExpected.order());
        assertEquals(m.order(), ORDER);
        assertEquals(mExpected, m);
    }

    // Test for order on non empty sorting machine
    @Test
    public final void testOrderNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2", "3", "4");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1", "2", "3", "4");

        assertEquals(m.order(), mExpected.order());
        assertEquals(m.order(), ORDER);
        assertEquals(mExpected, m);
    }

    // Test for size Zero when insertion mode
    @Test
    public final void testSizeZeroInsertionMode() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);

        assertEquals(m.size(), 0);
        assertEquals(mExpected, m);
    }

    // Test for size Zero when extraction mode
    @Test
    public final void testSizeZeroExtractionMode() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        assertEquals(m.size(), 0);
        assertEquals(mExpected, m);
    }

    // Test for size multiple when insertion mode
    @Test
    public final void testSizeMultipleInsertionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "purple", "green", "yellow", "red", "orange", "blue");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "purple", "green", "yellow", "red", "orange", "blue");

        final int six = 6;

        assertEquals(m.size(), six);
        assertEquals(mExpected, m);
    }

    // Test for size multiple when extraction mode
    @Test
    public final void testSizeMultipleExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "purple", "green", "yellow", "red", "orange", "blue");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "purple", "green", "yellow", "red", "orange", "blue");

        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();

        final int six = 6;

        assertEquals(m.size(), six);
        assertEquals(mExpected, m);
    }
}
