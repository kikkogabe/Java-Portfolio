import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.PriorityQueue;

import components.utilities.Reporter;

/**
 * Java program that generates a tag cloud from a given input text.
 *
 * @author Gabe Azzarita and Ty Fredrick
 *
 */
public final class TagCloudJAVA {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private TagCloudJAVA() {
    }

    /**
     * Compare entry values in numerical order.
     */
    private static class NumOrder
            implements Comparator<Entry<String, Integer>> {

        @Override
        /**
         * @param o1
         *            first pair
         * @param o2
         *            second pair
         * @ensures positive, negative, or zero int if o2.value is larger than,
         *          less than, or equal to o1.value
         *
         * @return int signaling which pair.value() is larger
         */
        public int compare(Entry<String, Integer> o1,
                Entry<String, Integer> o2) {
            return o2.getValue().compareTo(o1.getValue());
        }

    }

    /**
     * Compare entry keys in alphabetical order.
     */
    private static class AlphaOrder
            implements Comparator<Entry<String, Integer>> {

        @Override
        /**
         * @param o1
         *            first pair
         * @param o2
         *            second pair
         * @ensures positive, negative, or zero int if o1.key is larger than,
         *          less than, or equal to o2.key
         *
         * @return int signaling which pair.key() is alphabetically larger
         */
        public int compare(Entry<String, Integer> o1,
                Entry<String, Integer> o2) {
            return o1.getKey().compareTo(o2.getKey());
        }

    }

    /**
     * Minimum font value.
     */
    private static final int MIN_FONT = 11;

    /**
     * Maximum font value.
     */
    private static final int MAX_FONT = 48;

    /**
     * Fill set of separators with standard separators.
     *
     * @param s
     *            set of separators to fill
     * @ensures s contains ASCII characters [0, 65) + [91, 97) + [123, 127]
     *
     */
    private static void fillSeparator(HashSet<Character> s) {
        final int uppercaseStart = 65;
        final int uppercaseEnd = 91;
        final int lowercaseStart = 97;
        final int lowercaseEnd = 123;
        final int asciiEnd = 127;

        // Using ASCII values we can add all non-letters to our separator set
        for (int i = 0; i < uppercaseStart; i++) {
            s.add((char) i);
        }
        for (int k = uppercaseEnd; k < lowercaseStart; k++) {
            s.add((char) k);
        }
        for (int j = lowercaseEnd; j < asciiEnd; j++) {
            s.add((char) j);
        }
    }

    /**
     * Fill map by reading lines of input file.
     *
     * @param inFile
     *            valid text file to read
     * @param terms
     *            Map to fill with words and count of words
     * @param separators
     *            Set of separators
     * @throws IOException
     * @ensures "terms" contains all unique non-separator strings in text file
     *          as keys, while keeping count of words in value
     *
     */
    private static void fillMap(String inFile, HashMap<String, Integer> terms,
            HashSet<Character> separators) throws IOException {

        BufferedReader read = new BufferedReader(new FileReader(inFile));
        String tempLine = read.readLine();
        String tempWord = "";
        int position = 0;

        while (tempLine != null) {

            // Read each line of input using nextWordOrSeparator
            position = 0;
            while (position < tempLine.length()) {
                tempWord = nextWordOrSeparator(tempLine, position, separators);

                // Check that tempWord is NOT a separator
                if (!separators.contains(tempWord.charAt(0))) {
                    // make all words lowercase
                    tempWord = tempWord.toLowerCase();

                    // Check if tempWord is already in the map
                    if (!terms.containsKey(tempWord)) {
                        terms.put(tempWord, 1);
                    } else {
                        int value = terms.remove(tempWord);
                        terms.put(tempWord, value + 1);
                    }
                }
                position += tempWord.length();
            }
            tempLine = read.readLine();

        }
        read.close();

    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     * text[position, position + |nextWordOrSeparator|) and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     * entries(nextWordOrSeparator) intersection separators = {} and
     * (position + |nextWordOrSeparator| = |text| or
     * entries(text[position, position + |nextWordOrSeparator| + 1))
     * intersection separators /= {})
     * else
     * entries(nextWordOrSeparator) is subset of separators and
     * (position + |nextWordOrSeparator| = |text| or
     * entries(text[position, position + |nextWordOrSeparator| + 1))
     * is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            HashSet<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        String resultStr = "";
        String subStr = text.substring(position);
        char ch = text.charAt(position);
        boolean containsCh = separators.contains(ch);

        if (!containsCh) {
            // If first char is not separator, loop until separator is found
            for (int i = 0; i < subStr.length(); i++) {
                ch = text.charAt(position + i);
                if (!separators.contains(ch)) {
                    resultStr += ch;
                } else { // As soon as next char is separator
                    // Essentially a break
                    i = text.substring(position).length();
                }
            }
        } else { // Separator found, return separator
            resultStr += ch;
        }

        return resultStr;
    }

    /**
     * Print HTML file.
     *
     * @param o
     *            PrintWriter
     * @param inFile
     *            valid file cloudTag is based off
     * @param n
     *            generate tagCloud for top n words
     * @param maxCount
     *            largest count
     * @param pQ
     *            alphabetically ordered priority queue containing top n words
     * @throws IOException
     * @ensures printed HTML file "outFile" containing tagCloud from "inFile"
     *
     */
    private static void printHTML(PrintWriter o, String inFile, int n,
            PriorityQueue<Entry<String, Integer>> pQ, double maxCount) {

        // print header
        o.println("<html>");
        o.println("<head>");
        o.println("<title> Top " + n + " Words In " + inFile + "</title>");
        o.println("<link href=\"http://web.cse.ohio-state.edu/software/"
                + "2231/web-" + "sw2/assignments/projects/tag-cloud-generator/"
                + "data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");

        o.println("<link href=\"tagcloud.css\" rel=\"stylesheet\" "
                + "type=\"text/css\">");
        o.println("</head>");
        o.println("<body>");
        o.println("<h2> Top " + n + " Words In " + inFile + "</h2>");

        o.println("<hr>");

        o.println("<div class = \"cdiv\">");
        o.println("<p class = \"cbox\">");

        // Empty priority queue and print with font size calculated
        if (pQ.size() > 0) {

            int multiplier = (MAX_FONT - MIN_FONT);

            while (pQ.size() > 0) {
                Entry<String, Integer> tempPair = pQ.remove();

                //calculate font size
                double fontSize = ((tempPair.getValue() / maxCount) * multiplier
                        + MIN_FONT);

                o.println("<span style = \"cursor:default\" class = \"f"
                        + (int) fontSize + "\" title = \"count: "
                        + tempPair.getValue() + "\">" + tempPair.getKey()
                        + "</span>");
            }
        }

        // close each section of HTML
        o.println("</p>");
        o.println("</div>");
        o.println("</body>");
        o.println("</html>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {

        // read user input
        BufferedReader inUser = new BufferedReader(
                new InputStreamReader(System.in));

        /*
         * try opening files, vars created before try catch for scope
         */

        BufferedReader inF;
        PrintWriter out;
        String inFile = "";
        String outFile = "";
        try {
            System.out.print("Please enter an input file: ");
            inFile = inUser.readLine();
            inF = new BufferedReader(new FileReader(inFile));

            System.out.print("Please enter an output file: ");
            outFile = inUser.readLine();
            out = new PrintWriter(new BufferedWriter(new FileWriter(outFile)));
        } catch (IOException e) {
            System.err.println("Error opening file.");
            return;
        }

        /*
         * get N and check using parseInt. try catch for reading user input
         */

        int n = 0;
        try {
            System.out.print("Please enter number of words for tag cloud: ");
            n = Integer.parseInt(inUser.readLine());
            Reporter.assertElseFatalError(n > -1, "Number cannot be negative.");
        } catch (IOException e) {
            System.err.println("Unable to read input.");
        }

        /*
         * create and fill set with desired separators, then use set to fill a
         * map with unique words, while keeping count of word frequency
         */

        HashSet<Character> separators = new HashSet<Character>();
        fillSeparator(separators);

        HashMap<String, Integer> terms = new HashMap<String, Integer>();
        try {
            fillMap(inFile, terms, separators);
        } catch (IOException e) {
            System.err.println("Error reading file.");
        }

        /*
         * create a priority queue with descending numerical ordering and one
         * with alphabetical order. empty map into numerical PQ then remove the
         * first N items and add to alphabetical PQ
         */

        Comparator<Entry<String, Integer>> numericalSort = new NumOrder();
        PriorityQueue<Entry<String, Integer>> num = new PriorityQueue<>(
                numericalSort);

        for (Entry<String, Integer> p : terms.entrySet()) {
            num.add(p);
        }

        Comparator<Entry<String, Integer>> alphabetSort = new AlphaOrder();
        PriorityQueue<Entry<String, Integer>> alpha = new PriorityQueue<>(
                alphabetSort);

        double maxCount = 0; // used to calculate font size later

        for (int i = 0; i < n && num.size() > 0; i++) {
            Entry<String, Integer> p = num.remove();

            if (p.getValue() > maxCount) {
                maxCount = p.getValue();
            }

            alpha.add(p);
        }

        // try printing HTML page
        try {
            PrintWriter o = new PrintWriter(
                    new BufferedWriter(new FileWriter(outFile)));

            printHTML(o, inFile, n, alpha, maxCount);
            o.close();
        } catch (IOException e) {
            System.err.println("Error printing file.");
        }

        // try closing readers and writers
        try {
            inUser.close();
            inF.close();
            out.close();
        } catch (IOException e) {
            System.err.print("Error closing resources.");
        }

    }

}
